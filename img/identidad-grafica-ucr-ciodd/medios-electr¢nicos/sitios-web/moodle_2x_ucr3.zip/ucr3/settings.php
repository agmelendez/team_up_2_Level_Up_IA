<?php
/**
 * @package   theme_ucr3
 * @copyright 2014 Oficina de Divulgación e Información, Universidad de Costa Rica
 * @license   Todos los Derechos Reservados
 */

defined('MOODLE_INTERNAL') || die;

if ($ADMIN->fulltree) {

    // Invert Navbar to dark background.
    $name = 'theme_ucr3/invert';
    $title = get_string('invert', 'theme_ucr3');
    $description = get_string('invertdesc', 'theme_ucr3');
    $setting = new admin_setting_configcheckbox($name, $title, $description, 0);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settings->add($setting);

    // Logo file setting.
    $name = 'theme_ucr3/logo';
    $title = get_string('logo','theme_ucr3');
    $description = get_string('logodesc', 'theme_ucr3');
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'logo');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settings->add($setting);

    // Custom CSS file.
    $name = 'theme_ucr3/customcss';
    $title = get_string('customcss', 'theme_ucr3');
    $description = get_string('customcssdesc', 'theme_ucr3');
    $default = '';
    $setting = new admin_setting_configtextarea($name, $title, $description, $default);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settings->add($setting);

    // Footnote setting.
    $name = 'theme_ucr3/footnote';
    $title = get_string('footnote', 'theme_ucr3');
    $description = get_string('footnotedesc', 'theme_ucr3');
    $default = '';
    $setting = new admin_setting_confightmleditor($name, $title, $description, $default);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settings->add($setting);
	
	$options = array();
    $options['no'] = 'No';
    $options['si'] = 'Si';
	$name = 'theme_ucr3/nombre_sitio';
    $title = 'Nombre sitio arriba';
    $description = 'Desplegar el nombre del sitio arriba.';
    $default = 'no';
    $setting = new admin_setting_configselect($name, $title, $description, $default, $options);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settings->add($setting);
	
	$options = array();
    $options['no'] = 'No';
    $options['si'] = 'Si';
	$name = 'theme_ucr3/firma_grande';
    $title = 'Firma Grande';
    $description = 'Desplegar el encabezado con una firma UCR grande.';
    $default = 'no';
    $setting = new admin_setting_configselect($name, $title, $description, $default, $options);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settings->add($setting);
	
	$options = array();
    $options['celeste'] = 'Celeste';
    $options['azul'] = 'Azul';
	$options['blanco'] = 'Blanco';
	$name = 'theme_ucr3/color';
    $title = 'Color';
    $description = 'Color del tema de la plantilla.';
    $default = 'celeste';
    $setting = new admin_setting_configselect($name, $title, $description, $default, $options);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settings->add($setting);
}
