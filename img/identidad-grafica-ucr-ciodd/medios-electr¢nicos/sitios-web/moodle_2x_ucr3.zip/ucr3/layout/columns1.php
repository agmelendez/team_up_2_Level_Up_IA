<?php
/**
 * @package   theme_ucr3
 * @copyright 2014 Oficina de Divulgación e Información, Universidad de Costa Rica
 * @license   Todos los Derechos Reservados
 */

// Get the HTML for the settings bits.
$html = theme_ucr3_get_html_for_settings($OUTPUT, $PAGE);

	if($PAGE->theme->settings->firma_grande != "si")
		$class_desplazado = " class=\"desplazado\"";
	else
		$class_desplazado = "";
	$UBICACION_WEB = $CFG->wwwroot;
	$PLANTILLA = "/theme/".$PAGE->theme->name;
	$COMPRIMIR = "";
	$XX_LARGE = 2586;
	$X_LARGE = 2585;
	$LARGE = 1348;
	$MEDIUM = 1145;
	$TABLETA = 979;
	$HD_CEL = 640;
	$CEL = 392;
	$AZUL = false;
	$BLANCO = false;
	$COLOR = $PAGE->theme->settings->color;
	switch($COLOR)
	{
		case "azul": $AZUL = true; break;
		case "blanco": $BLANCO = true; break;
	}
	
	include $CFG->dirroot.$PLANTILLA."/browser.php";
	$browser = new Browser();
	$NAVEGADOR = strtolower($browser->getBrowser());
	$NAVEGADOR_VER = $browser->getVersion();
	if($NAVEGADOR == "internet explorer" && version_compare($NAVEGADOR_VER, '9', '<'))
		$IE8 = true;
	else
		$IE8 = false;
	$texto_sitio = "si";

echo $OUTPUT->doctype() ?>
<html <?php echo $OUTPUT->htmlattributes(); ?>>
<head>
    <title><?php echo $OUTPUT->page_title(); ?></title>    
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<link rel="image_src" href="<?php echo $UBICACION_WEB.$PLANTILLA; ?>/imagenes/firma-ucr-ico.png" />
<link rel="icon" href="<?php echo $UBICACION_WEB.$PLANTILLA; ?>/imagenes/ucr-favicon.png" type="image/png" />
<link rel="shortcut icon" type="image/x-icon" href="<?php echo $UBICACION_WEB.$PLANTILLA; ?>/imagenes/ucr-favicon.ico" />
<?php echo $OUTPUT->standard_head_html() ?>
<?php if($IE8) : ?>
<script language="javascript" type="text/javascript">
<!--
	var resolucion = '';	
	if (document.documentElement.offsetWidth <= <?php echo $MEDIUM; ?>)
		resolucion = 'medium';		
	else if (document.documentElement.offsetWidth <= <?php echo $LARGE; ?>)
		resolucion = 'large';
	else if (document.documentElement.offsetWidth <= <?php echo $X_LARGE; ?>)
		resolucion = 'x-large';
	else
		resolucion = 'xx-large';
-->
</script>
<?php endif; ?>
<?php
	echo "<link rel=\"stylesheet\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/comun".$COMPRIMIR.".css\" />";
	if($AZUL)
		echo "<link rel=\"stylesheet\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/azul".$COMPRIMIR.".css\" />";
	if($BLANCO)
		echo "<link rel=\"stylesheet\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/blanco".$COMPRIMIR.".css\" />";
	if($IE8) /* IE 8 no soporta mediaquieries */
	{		
		echo "
	<script language=\"javascript\" type=\"text/javascript\">	
	document.write ('<link rel=\"stylesheet\" type=\"text/css\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/comun-' + resolucion + '".$COMPRIMIR.".css\" />');
		</script>				
	<link rel=\"stylesheet\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/ie8".$COMPRIMIR.".css\" />
		";
	}   /* FIN IE 8 */
	else
	{
		echo "
	<link rel=\"stylesheet\" media=\"screen and (min-width: ".($X_LARGE + 1)."px)\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/comun-xx-large".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".$X_LARGE."px) and (min-width: ".($LARGE + 1)."px)\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/comun-x-large".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".$LARGE."px) and (min-width: ".($MEDIUM + 1)."px)\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/comun-large".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".$MEDIUM."px)\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/comun-medium".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".$TABLETA."px)\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/tableta".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (width: ".$HD_CEL."px)\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/cel-large".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".($HD_CEL - 1)."px)\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/cel-medium".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".$CEL."px)\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/cel-small".$COMPRIMIR.".css\" />
		";
	}

	echo "<link rel=\"stylesheet\" media=\"print\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/comun-x-large".$COMPRIMIR.".css\" />";
?>
</head>

<body id="ucr" <?php echo $OUTPUT->body_attributes(); ?>>

<?php echo $OUTPUT->standard_top_of_body_html() ?>

<a name="up" id="up"></a>
	<div id="marco-principal"<?php echo $class_desplazado; ?>>   


			
		<div id="encabezado"<?php echo $class_desplazado; ?>>
			<div class="contenido-interno">
				<?php if(isset($arriba_izquierda)) echo $arriba_izquierda; ?>
				<div id="firma" class="izquierda"><a href="http://www.ucr.ac.cr/" id="firma-ucr" title="Universidad de Costa Rica - Página principal"><span>Universidad de Costa Rica</span></a></div>
				<?php if(isset($logo) && $logo != "") : ?>
				<div class="logo">
					<?php echo "<img src=\"".$logo."\" style=\"max-height:80px\"/>"; ?>
				</div>	
				<?php elseif($PAGE->theme->settings->nombre_sitio == "si") : ?>
				<div class="logo"> <?php echo $html->heading; ?></div>
				<?php endif; ?> <!-- logo -->
				<?php if((isset($header_center) && $header_center != "") || (isset($arriba_centro) && $arriba_centro != "")) : ?>
				<div class="centro">				
					<?php echo $header_center; ?>
					<?php echo $arriba_centro; ?>
				</div>
				<?php endif; ?>				
				<?php if($OUTPUT->page_heading_button() != "") : ?>
				<div class="derecha" id="menus-iconos-funciones">
					<?php echo $OUTPUT->page_heading_button(); ?>				
				</div> <!-- arriba-derecha -->
				<?php endif; ?>
			</div> <!-- contenido-interno -->
		</div>	<!-- encabezado -->	
		
		<div id="centro-arriba"<?php echo $class_desplazado; ?>>			
			<div id="menus-principales">
				<div class="contenido-interno">
					<div class="navbar navbar-fixed-top<?php echo $html->navbarclass ?> moodle-has-zindex">
						<nav role="navigation" class="navbar-inner">
							<div class="container-fluid">
								<a class="brand" href="<?php echo $CFG->wwwroot;?>"><?php echo $SITE->shortname; ?></a>
								<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</a>
								<div class="nav-collapse collapse">
									<?php echo $OUTPUT->custom_menu(); ?>
									<ul class="nav pull-right">
										<li><?php echo $OUTPUT->page_heading_menu(); ?></li>
										<li class="navbar-text"><?php echo $OUTPUT->login_info() ?></li>
									</ul>
								</div>
							</div>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<div id="inicio-contenidos"></div>
		<!-- CENTRO_ARRIBA -->	
		<?php if(isset($banner_principal) && $banner_principal != "") : ?>
		<div class="banner_principal">
		<?php echo $banner_principal ?>
		</div>
		<?php endif; ?>
		<!-- BANNER_ARRIBA -->	
		<div id="contenidos" class="contenido-interno">	

			<div class="columna-principal<?php echo $con_izquierda.$con_derecha; ?>" id="columna-principal">
			<?php if($OUTPUT->course_header() != "") : ?>
			<div class="banner_sobre_ruta">
				<div id="course-header">
				<?php echo $OUTPUT->course_header(); ?>
				</div>
			</div>
			<?php endif; ?>
			<div class="borde">
				<div class="ruta">
					<?php echo $OUTPUT->navbar(); ?>
				</div>
				<?php if($bajo_ruta != "") : ?>
				<div class="bajo-ruta">
					<?php echo $bajo_ruta; ?>
				</div>
				<?php endif; ?>
				<div class="divisor">&nbsp;</div>
				<div id="principal">				
					<div id="page-content" class="row-fluid">
						<section id="region-main" class="span12">
									<?php
									echo $OUTPUT->course_content_header();
									echo $OUTPUT->main_content();
									echo $OUTPUT->course_content_footer();
									?>
								</section>
								<?php echo $OUTPUT->blocks('side-pre', 'span4 desktop-first-column'); ?>
							</div>
						</div>						
					</div>
				
				</div>
			</div> <!-- columna_principal -->
			</div><!-- centro -->	
		</div>  <!-- contenidos -->
		
		<div id="pie-pagina">
			<div class="contenido-interno" >
			<div class="izquierda">
				<?php
				echo $html->footnote;
				echo $OUTPUT->login_info();
				echo $OUTPUT->home_link();
				echo $OUTPUT->standard_footer_html();
				?>
			</div>	
			<div class="derecha">
				<div id="course-footer"><?php echo $OUTPUT->course_footer(); ?></div>
				<p class="helplink"><?php echo $OUTPUT->page_doc_link(); ?></p>
			</div>
			</div>
		</div>
		<?php echo $OUTPUT->standard_end_of_body_html() ?>
    </div> <!-- marco-principal -->	
	
	<a name="down" id="down"></a>

<?php if($IE8) : ?>
<script type="text/javascript" src="<?php echo $UBICACION_WEB.$PLANTILLA; ?>/js/jquery-1.11.1<?php echo $SALIDA['COMPRIMIR']; ?>.js"></script>
<script type="text/javascript" src="<?php echo $UBICACION_WEB.$PLANTILLA; ?>/js/raphael<?php echo $COMPRIMIR; ?>.js"></script>
<?php else : ?>
<script type="text/javascript" src="<?php echo $UBICACION_WEB.$PLANTILLA; ?>/js/jquery-2.1.1<?php echo $SALIDA['COMPRIMIR']; ?>.js"></script>
<?php endif; ?>
<script type="text/javascript" src="<?php echo $UBICACION_WEB.$PLANTILLA; ?>/js/jquery.hoverIntent<?php echo $SALIDA['COMPRIMIR']; ?>.js"></script>
<script language="javascript" type="text/javascript">
<!--
	
	function Tactil()
	{
		return (Modernizr.touch || Modernizr.testAllProps('pointerEvents'));
	}
	
	var escondidoMenuArriba = null;
	var abiertoMenuArriba = false;
	var abiertoMenuArribaInterno = false;  // Esta abierto un submenu
	var ultimoSubmenu = -1;
	var menuSuperiorGrande = true;
	var estadoAnteriorMenuSuperior = true;
	
	jQuery(document).ready(function() 
	{
		if(jQuery(window).width() <= <?php echo $HD_CEL; ?>)
		{
			menuSuperiorGrande = false;
			estadoAnteriorMenuSuperior = false;
			mostrarOpcionesBuscar = true;
		}
		
		jQuery.fn.slideFadeToggle = function(speed, easing, estado, callback) 
		{					
			return this.animate({opacity: 'toggle', height: 'toggle'}, speed, easing, callback);
		};			
		
		function alternarMenuArriba(estado)
		{
			if(estado == 0 || (estado == -1 && abiertoMenuArriba === true) || (estado == 1 && abiertoMenuArriba === false))
			{
				if(jQuery(window).width() <= <?php echo $HD_CEL; ?>)
				{					
					jQuery('#centro-arriba').slideFadeToggle('fast', 'linear');
					if(escondidoMenuArriba === null)
					{
						if(estado == -1)
							escondidoMenuArriba = true;
						else
							escondidoMenuArriba = false;
					}
					else
						escondidoMenuArriba = !escondidoMenuArriba;
				}
				else
				{
					jQuery('#centro-arriba ul.menu ul').slideFadeToggle('fast', 'linear');
					abiertoMenuArriba = !abiertoMenuArriba;
				}
			}
		}
		
		function abrirMenuArriba()
		{
			alternarMenuArriba(1);
		}
		
		function cerrarMenuArriba()
		{
			alternarMenuArriba(-1);
		}	
	
		AcondicionarMenus = function()
		{			
			if(jQuery(window).width() > <?php echo $HD_CEL; ?>)
			{
				if(ultimoSubmenu > -1)
				{
					jQuery('#centro-arriba ul.menu li.expanded').eq(ultimoSubmenu).children('ul.menu ul').slideFadeToggle('fast', 'linear');
					ultimoSubmenu = -1;
				}
				if(escondidoMenuArriba !== null && escondidoMenuArriba)
				{
					jQuery('#centro-arriba').slideFadeToggle('fast', 'linear');
					escondidoMenuArriba = false;
				}
				abiertoMenuArriba = false;				
				jQuery('#centro-arriba ul.menu li.expanded').unbind('click');
				jQuery('#centro-arriba ul.menu li.expanded').children().unbind('click');
				jQuery('#menus-principales').hoverIntent(abrirMenuArriba, cerrarMenuArriba);				
				jQuery('#marco-principal').removeClass('movil');				
			}
			else
			{
				if(escondidoMenuArriba !== null && !escondidoMenuArriba)
				{
					jQuery('#centro-arriba').slideFadeToggle('fast', 'linear');
					escondidoMenuArriba = true;
				}
				jQuery('#marco-principal').addClass('movil');
				jQuery('#menus-principales').unbind('mouseenter').unbind('mouseleave');
				jQuery('#centro-arriba ul.menu > li').bind('click', function(event) {
					if(event.target === this) 
					{
						if(ultimoSubmenu > -1)
							jQuery('#centro-arriba ul.menu > li').eq(ultimoSubmenu).children('ul.menu ul').slideFadeToggle('fast', 'linear');
						if(ultimoSubmenu != jQuery(this).index())
						{		
							ultimoSubmenu = jQuery(this).index();
							jQuery(this).children('ul.menu ul').slideFadeToggle('fast', 'linear');							
						}
						else
							ultimoSubmenu = -1;
					}
				});
				
				jQuery('#centro-arriba ul.menu li.expanded').children().bind('click', function(event) {
					event.stopPropagation();
				});				
			}
		}		
		
		jQuery('.lateral ul li.expanded').hoverIntent(function ()
		{
			jQuery(this).children('ul').animate({opacity: 'toggle', height: 'toggle'}, 'fast', 'linear');
		}, function ()
		{
			jQuery(this).children('ul').animate({opacity: 'toggle', height: 'toggle'}, 'fast', 'linear');
		});
		
		jQuery('#menus-principales').focusin(function()
		{
			if(escondidoMenuArriba === null || escondidoMenuArriba)
				abrirMenuArriba();
		});	
		
		jQuery('#menus-principales').focusout(function()
		{
			if(!jQuery(document.activeElement).closest('#menus-principales').length && !escondidoMenuArriba)			
				cerrarMenuArriba();
		});
		
		jQuery(window).resize(function() 
		{
			if(jQuery(window).width() > <?php echo $HD_CEL; ?>)
				menuSuperiorGrande = true;
			else
				menuSuperiorGrande = false;
			if(estadoAnteriorMenuSuperior != menuSuperiorGrande)
			{
				AcondicionarMenus();
			}
			estadoAnteriorMenuSuperior = menuSuperiorGrande;
		});
		
		AcondicionarMenus();
		<?php if($IE8) : ?>
		jQuery.getScript('<?php echo $UBICACION_WEB.$PLANTILLA; ?>/js/firma-ucr.js');
		<?php endif; ?>
	});	
-->
</script>
	
</body>
</html>
	
