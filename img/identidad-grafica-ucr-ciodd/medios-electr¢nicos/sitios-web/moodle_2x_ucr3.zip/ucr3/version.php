<?php
/**
 * @package   theme_ucr3
 * @copyright 2015 Oficina de Divulgación e Información, Universidad de Costa Rica
 * @license   Todos los Derechos Reservados
 */

defined('MOODLE_INTERNAL') || die;

$plugin->version   = 2016060200;
$plugin->requires  = 2014050800;
$plugin->component = 'theme_ucr3';
$plugin->dependencies = array(
    'theme_bootstrapbase'  => 2014050800,
);
