<?php

/**
 * Strings for component 'theme_ucr3', language 'en'
 *
 * @package   theme_ucr3
 * @copyright 2014 Oficina de Divulgación e Información, Universidad de Costa Rica
 * @license   Todos los Derechos Reservados
 */

$string['choosereadme'] = '
<div>
<h2>UCR 3</h2>
<p><img src="clean/pix/screenshot.jpg" /></p>
</div>
<div>
<h3>Acerca de</h3>
<p>UCR 3 es el estilo visual estándar definido por la Oficina de Divulgación e Información para sitios web de la Universidad de Costa Rica. Para más información remítase a la dirección http://www.odi.ucr.ac.cr/linea-grafica/ y descarge el manual de desarrollo de sitios web.</p>
<h3>Theme Credits</h3>
<p>Autor: Esteban Aguilar B. Diseño: Ana María Sibaja<br>
Contacto: <a href="mailto:esteban.aguilar@ucr.ac.cr">esteban.aguilar@ucr.ac.cr</a><br>
Sitio: <a href="http://odi.ucr.ac.cr">http://odi.ucr.ac.cr</a>
</p>
</div>';

$string['configtitle'] = 'UCR 3';

$string['customcss'] = 'Custom CSS';
$string['customcssdesc'] = 'Whatever CSS rules you add to this textarea will be reflected in every page, making for easier customization of this theme.';

$string['footnote'] = 'Footnote';
$string['footnotedesc'] = 'Whatever you add to this textarea will be displayed in the footer throughout your Moodle site.';

$string['invert'] = 'Invert navbar';
$string['invertdesc'] = 'Swaps text and background for the navbar at the top of the page between black and white.';

$string['logo'] = 'Logo';
$string['logodesc'] = 'Please upload your custom logo here if you want to add it to the header.<br>
If the height of your logo is more than 75px add the following CSS rule to the Custom CSS box below.<br>
a.logo {height: 100px;} or whatever height in pixels the logo is.';

$string['pluginname'] = 'UCR 3';

$string['region-side-post'] = 'Right';
$string['region-side-pre'] = 'Left';

