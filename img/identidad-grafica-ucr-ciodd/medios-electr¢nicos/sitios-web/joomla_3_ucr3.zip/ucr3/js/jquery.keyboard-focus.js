/**
 * jquery.keyboard-focus.js (defines classes for when focus was obtained via the keyboard)
 * 
 * @version 0.3
 * Modificado por Esteban Aguilar Barrantes EAB. 30/10/2015
 * Changelog:
 *   * 0.1 Initial implementation
 *   * 0.2 Added support for 'focus' class to appear whenever an element is foccued. 
 *     Useful for browsers like IE6 that don't support :focus
 *   * 0.3 Added support for 'mouse-focus' class so that :focus styles can be strong for keyboard by default
 *     with more subtle style for .mouse-focus events.
 * 
 * @author Andrew Ramsden
 * @see http://irama.org/web/dhtml/key-focus/
 * @license Common Public License Version 1.0 <http://www.opensource.org/licenses/cpl1.0.txt>
 * @requires jQuery (tested with version 1.3.1) <http://jquery.com/>
 */

if (typeof jQuery == 'undefined') {
	if (console && console.log) { console.log('Keyboard Focus plugin could not be initialised because jQuery is not available'); }
} else { /* Start if jQuery exists */

jQuery.keyFocus = {};
jQuery.keyFocus.conf = {
	keyFocusClass : 'keyboard-focus',
	mouseFocusClass : 'mouse-focus',
	focusClass : 'focus',
	mouseTimeout  : 50
};

(function($){ /* start closure (protects variables from global scope) */
	
	$(document).ready(function(){
		$('body').trackFocus();
	});
	
	/**
	 * @see http://www.w3.org/TR/wai-aria-practices/#kbd_generalnav
	 * @param DOMNode this The container element that acts as "toolbar" for the controls.
	 * @param jQuerySelector controlSelector Individual controls to navigate between.
	 * @param Object options A set of options to override the $.AKN.defaultOptions. 
	 */
	$.fn.trackFocus = function () {		
		var element = $(this);
		
		element.data('last-device-used', '');
		
		element
			.bind('blur', function(e){
				element.data('last-device-used', 'unknown');
			})		
			.bind('mousedown', function(e){
				element.data('last-device-used', 'mouse');
			})
			.bind('mouseup', function(e){
				var event = jQuery.Event( 'MixedFocusIn' );
				event.source = 'mouse';
				$(e.target).addClass($.keyFocus.conf.mouseFocusClass);	
				$(e.target).addClass($.keyFocus.conf.focusClass);
				$(e.target).trigger( event );
			})
			.bind('keydown', function(e){
				element.data('last-device-used', 'keyboard');
				// EAB: cambios para detectar teclado correctamente y desencadenar un evento **************
				if(e.keyCode === 9) 
				{			
					if (e.shiftKey === true)
						element.data('key', 'shifttab');
					else
						element.data('key', 'tab');
				}				
				element.data('last-device-used-when', new Date().getTime());
				/***********************/
			})
			.bind('focusin', function(e){
				// EAB: cambios para detectar teclado correctamente y desencadenar un evento *************
				var event = jQuery.Event( 'MixedFocusIn' );
				if (element.data('last-device-used') == 'keyboard') {
					event.source = 'keyboard';
					if(element.data('key') == 'tab')
						event.direction = 'tab';
					else
						event.direction = 'shifttab';
					$(e.target).addClass($.keyFocus.conf.keyFocusClass);	
					$(e.target).addClass($.keyFocus.conf.focusClass);
					$(e.target).trigger( event );
					/****************************/
				} else if (element.data('last-device-used') != 'mouse') {
					event.source = 'unknown';
				
					$(e.target).addClass($.keyFocus.conf.focusClass);
					$(e.target).trigger( event );
				} 
			})
			.bind('focusout', function(e){
				$('.'+$.keyFocus.conf.keyFocusClass+', .'+$.keyFocus.conf.mouseFocusClass).removeClass($.keyFocus.conf.keyFocusClass+' '+$.keyFocus.conf.mouseFocusClass);
				$(e.target).removeClass($.keyFocus.conf.focusClass);
				// EAB: cambios para detectar teclado correctamente y desencadenar un evento ****
				var event = jQuery.Event( 'MixedFocusOut' );
				if(element.data('last-device-used') == 'keyboard') 
				{				
					event.source = 'keyboard';
					if(element.data('key') == 'tab')
						event.direction = 'tab';
					else
						event.direction = 'shifttab';
				}
				else if(element.data('last-device-used') == 'mouse') 
					event.source = 'mouse';
				else 
					event.source = 'unknown';
				$(e.target).trigger( event );
				/****************************/
			})
		;
	};
		
	
	
})(jQuery); /* end closure */
} /* end if jQuery exists */