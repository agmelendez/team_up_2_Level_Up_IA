<?php
// no direct access
 defined( '_JEXEC' ) or die;
?><!DOCTYPE html>
<html>
<head>
<?php 

	jimport('joomla.environment.browser');
	$document = JFactory::getDocument();
	$browser = JBrowser::getInstance();
	$browserType = $browser->getBrowser();
	$browserVersion = $browser->getMajor();
	if(($browserType == 'msie') && ($browserVersion < 9))
		$IE8 = true;
	else
		$IE8 = false;

	// Inicializando algunas variables:
	$columna_izquierda = false;
	$columna_derecha = false;
	$AZUL = false;
	$BLANCO = false;
	$con_izquierda = "";
	$con_derecha = "";
	if ($this->countModules('left or izquierda_arriba or izquierda_abajo or position-7'))
	{
		$columna_izquierda = true;
		$con_izquierda = " con-IZQUIERDA";
	}
	if($this->countModules('right or derecha or logo2'))
	{
		$columna_derecha = true;
		$con_derecha = " con-DERECHA";
	}

	$UBICACION_WEB = JURI::base();
	$PLANTILLA = $this->template;
	$RESOLUCION = $this->params->get('dimensiones');
	$COLOR = $this->params->get('color');
	switch($COLOR)
	{
		case "azul": $AZUL = true; break;
		case "blanco": $BLANCO = true; break;
	}
	$APPLICATION = JFactory::getApplication();
	$COMPRIMIR = "";
	$XX_LARGE = 2586;
	$X_LARGE = 2585;
	$LARGE = 1348;
	$MEDIUM = 1145;
	$TABLETA = 1024;
	$HD_CEL = 640;
	$CEL = 392;


if($IE8)
{
	$document->addScript(JURI::base() . "templates/".$PLANTILLA."/js/jquery-1.11.1".$COMPRIMIR.".js");
	$document->addScript(JURI::base() . "templates/".$PLANTILLA."/js/raphael".$COMPRIMIR.".js");
	$FIRMA_UCR_IE8_RAPHAEL = "jQuery.getScript('".$UBICACION_WEB."templates/".$PLANTILLA."/js/firma-ucr.js');";
}
else
{
	$document->addScript(JURI::base() . "templates/".$PLANTILLA."/js/jquery-2.1.1".$COMPRIMIR.".js");
	$FIRMA_UCR_IE8_RAPHAEL = "";
}
$document->addScript(JURI::base() . "templates/".$PLANTILLA."/js/jquery.hoverIntent".$COMPRIMIR.".js");


$codigo_javascript = "
	function Tactil()
	{
		return (Modernizr.touch || Modernizr.testAllProps('pointerEvents'));
	}
	
	var escondidoMenuArriba = null;
	var abiertoMenuArriba = false;
	var abiertoMenuArribaInterno = false;  // Esta abierto un submenu
	var ultimoSubmenu = -1;
	var menuSuperiorGrande = true;
	var estadoAnteriorMenuSuperior = true;
	
	jQuery(document).ready(function() 
	{
		if(jQuery(window).width() <= ".$HD_CEL.")
		{
			menuSuperiorGrande = false;
			estadoAnteriorMenuSuperior = false;
			mostrarOpcionesBuscar = true;
		}
		
		jQuery.fn.slideFadeToggle = function(speed, easing, estado, callback) 
		{					
			return this.animate({opacity: 'toggle', height: 'toggle'}, speed, easing, callback);
		};			
		
		function alternarMenuArriba(estado)
		{
			if(estado == 0 || (estado == -1 && abiertoMenuArriba === true) || (estado == 1 && abiertoMenuArriba === false))
			{
				if(jQuery(window).width() <= ".$HD_CEL.")
				{					
					jQuery('#centro-arriba').slideFadeToggle('fast', 'linear');
					if(escondidoMenuArriba === null)
					{
						if(estado == -1)
							escondidoMenuArriba = true;
						else
							escondidoMenuArriba = false;
					}
					else
						escondidoMenuArriba = !escondidoMenuArriba;
				}
				else
				{
					jQuery('#centro-arriba ul.menu ul').slideFadeToggle('fast', 'linear');
					abiertoMenuArriba = !abiertoMenuArriba;
				}
			}
		}
		
		function abrirMenuArriba()
		{
			alternarMenuArriba(1);
		}
		
		function cerrarMenuArriba()
		{
			alternarMenuArriba(-1);
		}
		
		jQuery('a.mostrar-menu').on('click', function () 
		{		
			alternarMenuArriba(0);
			if(abiertoMenuArribaInterno)
			{
				jQuery('#centro-arriba ul.menu ul').slideFadeToggle('fast', 'linear');
				abiertoMenuArribaInterno = !abiertoMenuArribaInterno;
			}
		});	
		
		AcondicionarMenus = function()
		{			
			if(jQuery(window).width() > ".$HD_CEL.")
			{
				if(ultimoSubmenu > -1)
				{
					jQuery('#centro-arriba ul.menu li.parent').eq(ultimoSubmenu).children('ul.menu ul').slideFadeToggle('fast', 'linear');
					ultimoSubmenu = -1;
				}
				if(escondidoMenuArriba !== null && escondidoMenuArriba)
				{
					jQuery('#centro-arriba').slideFadeToggle('fast', 'linear');
					escondidoMenuArriba = false;
				}
				abiertoMenuArriba = false;				
				jQuery('#centro-arriba ul.menu li.parent').unbind('click');
				jQuery('#centro-arriba ul.menu li.parent').children().unbind('click');
				jQuery('#menus-principales').hoverIntent(abrirMenuArriba, cerrarMenuArriba);				
				jQuery('#marco-principal').removeClass('movil');				
			}
			else
			{
				if(escondidoMenuArriba !== null && !escondidoMenuArriba)
				{
					jQuery('#centro-arriba').slideFadeToggle('fast', 'linear');
					escondidoMenuArriba = true;
				}
				jQuery('#marco-principal').addClass('movil');
				jQuery('#menus-principales').unbind('mouseenter').unbind('mouseleave');
				jQuery('#centro-arriba ul.menu > li').bind('click', function(event) {
					if(event.target === this) 
					{
						if(ultimoSubmenu > -1)
							jQuery('#centro-arriba ul.menu > li').eq(ultimoSubmenu).children('ul.menu ul').slideFadeToggle('fast', 'linear');
						if(ultimoSubmenu != jQuery(this).index())
						{		
							ultimoSubmenu = jQuery(this).index();
							jQuery(this).children('ul.menu ul').slideFadeToggle('fast', 'linear');							
						}
						else
							ultimoSubmenu = -1;
					}
				});
				
				jQuery('#centro-arriba ul.menu li.parent').children().bind('click', function(event) {
					event.stopPropagation();
				});				
			}
		}		
		
		jQuery('.lateral ul li.parent').hoverIntent(function ()
		{
			jQuery(this).children('ul').animate({opacity: 'toggle', height: 'toggle'}, 'fast', 'linear');
		}, function ()
		{
			jQuery(this).children('ul').animate({opacity: 'toggle', height: 'toggle'}, 'fast', 'linear');
		});
		
		jQuery('#menus-principales').focusin(function()
		{
			if(escondidoMenuArriba === null || escondidoMenuArriba)
				abrirMenuArriba();
		});	
		
		jQuery('#menus-principales').focusout(function()
		{
			if(!jQuery(document.activeElement).closest('#menus-principales').length && !escondidoMenuArriba)			
				cerrarMenuArriba();
		});
		
		jQuery(window).resize(function() 
		{
			if(jQuery(window).width() > ".$HD_CEL.")
				menuSuperiorGrande = true;
			else
				menuSuperiorGrande = false;
			if(estadoAnteriorMenuSuperior != menuSuperiorGrande)
			{
				AcondicionarMenus();
			}
			estadoAnteriorMenuSuperior = menuSuperiorGrande;
		});
		
		AcondicionarMenus();
		
		".$FIRMA_UCR_IE8_RAPHAEL."
	});
	
";

$document->addScriptDeclaration($codigo_javascript);	
	
?>
<jdoc:include type="head" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<link rel="image_src" href="<?php echo $UBICACION_WEB; ?>templates/<?php echo $PLANTILLA; ?>/imagenes/firma-ucr-ico.png" />
<link rel="icon" href="<?php echo $UBICACION_WEB; ?>templates/<?php echo $PLANTILLA; ?>/imagenes/ucr-favicon.png" type="image/png" />
<link rel="shortcut icon" type="image/x-icon" href="<?php echo $UBICACION_WEB; ?>templates/<?php echo $PLANTILLA; ?>/imagenes/ucr-favicon.ico" />
<?php if($IE8) : ?>
<script language="javascript" type="text/javascript">
<!--
	var resolucion = '';	
	if (document.documentElement.offsetWidth <= <?php echo $MEDIUM; ?>)
		resolucion = 'medium';		
	else if (document.documentElement.offsetWidth <= <?php echo $LARGE; ?>)
		resolucion = 'large';
	else if (document.documentElement.offsetWidth <= <?php echo $X_LARGE; ?>)
		resolucion = 'x-large';
	else
		resolucion = 'xx-large';
-->
</script>
<?php endif; ?>
<?php
	echo "<link rel=\"stylesheet\" href=\"".$UBICACION_WEB."templates/".$PLANTILLA."/css/comun".$COMPRIMIR.".css\" />";
	if($AZUL)
		echo "<link rel=\"stylesheet\" href=\"".$UBICACION_WEB."templates/".$PLANTILLA."/css/azul".$COMPRIMIR.".css\" />";
	if($BLANCO)
		echo "<link rel=\"stylesheet\" href=\"".$UBICACION_WEB."templates/".$PLANTILLA."/css/blanco".$COMPRIMIR.".css\" />";
	if($IE8) /* IE 8 no soporta mediaquieries */
	{		
		echo "
	<script language=\"javascript\" type=\"text/javascript\">	
	document.write ('<link rel=\"stylesheet\" type=\"text/css\" href=\"".$UBICACION_WEB."templates/".$PLANTILLA."/css/comun-' + resolucion + '".$COMPRIMIR.".css\" />');
		</script>				
	<link rel=\"stylesheet\" href=\"".$UBICACION_WEB."templates/".$PLANTILLA."/css/ie8".$COMPRIMIR.".css\" />
		";
	}   /* FIN IE 8 */
	else
	{
		echo "
	<link rel=\"stylesheet\" media=\"screen and (min-width: ".($X_LARGE + 1)."px)\" href=\"".$UBICACION_WEB."templates/".$PLANTILLA."/css/comun-xx-large".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".$X_LARGE."px) and (min-width: ".($LARGE + 1)."px)\" href=\"".$UBICACION_WEB."templates/".$PLANTILLA."/css/comun-x-large".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".$LARGE."px) and (min-width: ".($MEDIUM + 1)."px)\" href=\"".$UBICACION_WEB."templates/".$PLANTILLA."/css/comun-large".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".$MEDIUM."px)\" href=\"".$UBICACION_WEB."templates/".$PLANTILLA."/css/comun-medium".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".$TABLETA."px)\" href=\"".$UBICACION_WEB."templates/".$PLANTILLA."/css/tableta".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (width: ".$HD_CEL."px)\" href=\"".$UBICACION_WEB."templates/".$PLANTILLA."/css/cel-large".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".($HD_CEL - 1)."px)\" href=\"".$UBICACION_WEB."templates/".$PLANTILLA."/css/cel-medium".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".$CEL."px)\" href=\"".$UBICACION_WEB."templates/".$PLANTILLA."/css/cel-small".$COMPRIMIR.".css\" />
		";
	}
	echo "<link rel=\"stylesheet\" media=\"print\" href=\"".$UBICACION_WEB."templates/".$PLANTILLA."/css/comun-x-large".$COMPRIMIR.".css\" />";
	echo "<link rel=\"stylesheet\" href=\"".$UBICACION_WEB."templates/".$PLANTILLA."/css/template.css\" />";
	if($this->params->get('firma_grande') != "si")
		$class_desplazado = " class=\"desplazado\"";
	else
		$class_desplazado = "";
?>
</head>

<body id="ucr">
<a name="up" id="up"></a>
	<div id="marco-principal"<?php echo $class_desplazado; ?>>   			
		<div id="encabezado"<?php echo $class_desplazado; ?>>
			<div class="contenido-interno">
				<div id="firma" class="izquierda"><a href="http://www.ucr.ac.cr/" id="firma-ucr" title="Universidad de Costa Rica - Página principal"><span>Universidad de Costa Rica</span></a></div>
				<?php if($this->countModules('logo')) : ?>
				<div class="logo">
					<jdoc:include type="modules" name="logo" />
				</div>	
				<?php elseif($this->params->get('nombre_sitio') == "si") : ?>
				<div class="logo"><?php echo htmlspecialchars($APPLICATION->getCfg('sitename')); ?></div>
				<?php endif; ?> <!-- logo -->
				<?php if($this->countModules('arriba_centro')) : ?>				
				<div class="centro">				
					<jdoc:include type="modules" name="top" />
					<jdoc:include type="modules" name="arriba_centro" />
				</div>
				<?php endif; ?>				
				<div class="derecha" id="menus-iconos-funciones">
				<jdoc:include type="modules" name="position-0" />
				<jdoc:include type="modules" name="arriba_derecha" />
				<jdoc:include type="modules" name="pestana" />
				<div class="movil"><a class="mostrar-menu"><img src="<?php echo $UBICACION_WEB; ?>templates/<?php echo $PLANTILLA; ?>/imagenes/menu.png" alt="Mostrar Enlaces" title="Mostrar Enlaces" /></a></div>
				</div> <!-- arriba-derecha -->
			</div> <!-- contenido-interno -->
		</div>	<!-- encabezado -->	
		
		<?php if($this->countModules('centro_arriba or position-1')) : ?>	
		<div id="centro-arriba"<?php echo $class_desplazado; ?>>			
			<div id="menus-principales">
				<div class="contenido-interno">
				<jdoc:include type="modules" name="position-1" />
				<jdoc:include type="modules" name="centro_arriba" />
				</div>
			</div>
		</div>
		<div id="inicio-contenidos"></div>
		<?php endif; ?> <!-- CENTRO_ARRIBA -->	
		<?php if($this->countModules('banner_principal')) : ?>
		<div class="banner_principal">
		<jdoc:include type="modules" name="banner_principal" />
		</div>
		<?php endif; ?>
		<jdoc:include type="modules" name="position-5" /> <!-- BANNER_ARRIBA -->	
		<div id="contenidos" class="contenido-interno">
			<?php if($this->countModules('left or izquierda_arriba or izquierda_abajo or position-7')) : ?>
			<div class="columna-izquierda lateral" id="columna-izquierda">					
				<?php if($this->countModules('left or izquierda_arriba')) : ?>							
					<div class="arriba">
					<jdoc:include type="modules" name="left" style="rounded" />
					<jdoc:include type="modules" name="izquierda_arriba" style="rounded" />
					</div>
				<?php endif; ?>
				<?php if($this->countModules('position-7 or izquierda_abajo')) : ?>
					<div class="abajo">					
					<jdoc:include type="modules" name="izquierda_abajo" style="rounded" />
					<jdoc:include type="modules" name="position-7" />
					</div>
				<?php endif; ?>
			</div> <!-- columna_izquierda -->

			<?php endif; ?>			

			<div class="columna-principal<?php echo $con_izquierda.$con_derecha; ?>" id="columna-principal">
			<?php if($this->countModules('banner_sobre_ruta')) : ?>
			<div class="banner_sobre_ruta">
			<jdoc:include type="modules" name="banner_sobre_ruta" />
			</div>
			<?php endif; ?>
			<div class="borde">
				<?php if($this->countModules('breadcrumb')) : ?>
					<div class="ruta">
						<jdoc:include type="modules" name="breadcrumb" />						
					</div>
				<?php elseif($this->countModules('ruta')) : ?>
				<?php  ?>
					<div class="ruta">
						<jdoc:include type="modules" name="ruta" />					
					</div>
				<?php endif; ?>
				<?php if($this->countModules('bajo_ruta')) : ?>
					<div class="bajo-ruta">
					<jdoc:include type="modules" name="bajo_ruta" />
					</div>
				<?php endif; ?>
				<div class="divisor">&nbsp;</div>
				<jdoc:include type="message" />
				<jdoc:include type="component" />
				<jdoc:include type="modules" name="centro_abajo" />				
			</div> <!-- columna_principal -->
			</div><!-- centro -->
			
			<?php if($this->countModules('right or derecha or logo2')) : ?>
			<div class="columna-derecha lateral" id="columna-derecha">
				<jdoc:include type="modules" name="logo2" />				
				<jdoc:include type="modules" name="derecha" style="xhtml" />
				<jdoc:include type="modules" name="right" style="xhtml"/>
			</div> <!-- columna_derecha -->			
			<?php endif; ?>

			<?php if($this->countModules('syndicate or abajo_centro')) : ?>
			<div class="suscripciones centro-abajo">
				<jdoc:include type="modules" name="syndicate" />
				<jdoc:include type="modules" name="abajo_centro" />
			</div>
			<?php endif; ?>
		</div>  <!-- contenidos -->
		
		<?php  if($this->countModules('pie_derecha or pie or footer')) : ?>
		<div id="pie-pagina">
			<div class="contenido-interno" >
			<?php  if($this->countModules('pie or footer')) : ?>
			<div class="izquierda">
				<jdoc:include type="modules" name="pie" />
				<jdoc:include type="modules" name="footer" style="xhtml"/>
			</div>	
			<?php endif; ?>
			<?php if($this->countModules('pie_centro')) : ?>
			<div class="centro">
				<jdoc:include type="modules" name="pie_centro" />
			</div>
			<?php endif; ?>
			<?php if($this->countModules('pie_derecha')) : ?>
			<div class="derecha">
				<jdoc:include type="modules" name="pie_derecha" />
			</div>
			<?php endif; ?>
			</div>
		</div>
		<?php endif; ?>	<!-- pies --> 	
    </div> <!-- marco-principal -->	
	
	<?php if($this->countModules('abajo')) : ?>
	<div class="divisor_inferior">
		<jdoc:include type="modules" name="abajo" />
	</div> <!-- divisor_inferior -->		
	<?php endif; ?>	<!-- abajo -->
	<jdoc:include type="modules" name="debug" />	
	<a name="down" id="down"></a>
</body>
</html>