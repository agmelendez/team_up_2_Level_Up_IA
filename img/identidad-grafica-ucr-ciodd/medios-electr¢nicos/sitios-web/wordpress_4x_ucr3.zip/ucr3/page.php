<?php

get_header(); ?>

	<div id="contenidos" class="contenido-interno content-area">
	<!-- <div id="primary" class="content-area"> -->
		<div class="columna-principal" id="columna-principal">

		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();

			// Include the page content template.
			get_template_part( 'content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		// End the loop.
		endwhile;
		?>

		</div><!-- .columna-principal -->
	</div><!-- .content-area -->

<?php get_footer(); ?>
