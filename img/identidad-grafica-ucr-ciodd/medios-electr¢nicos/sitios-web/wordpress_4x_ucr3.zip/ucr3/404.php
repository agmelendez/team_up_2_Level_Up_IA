<?php

get_header(); ?>

	<div id="primary" class="content-area">
		<div class="columna-derecha lateral" id="columna-derecha secondary">

			<section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title">No se encuentra la página.</h1>
				</header><!-- .page-header -->

				<div class="page-content">
					<p>Intente de nuevo o contacte al administrador.</p>

					<?php get_search_form(); ?>
				</div><!-- .page-content -->
			</section><!-- .error-404 -->

		</div><!-- .columna-principal -->
	</div><!-- .content-area -->

<?php get_footer(); ?>
