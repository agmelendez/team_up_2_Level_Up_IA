<?php
</div><!-- .content-area -->

get_header(); ?>

	<div id="contenidos" class="contenido-interno content-area">
	<!-- <div id="primary" class="content-area"> -->
		<div class="columna-principal" id="columna-principal">

		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();

			/*
			 * Include the post format-specific template for the content. If you want to
			 * use this in a child theme, then include a file called called content-___.php
			 * (where ___ is the post format) and that will be used instead.
			 */
			get_template_part( 'content', get_post_format() );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

			// Previous/next post navigation.
			the_post_navigation( array(
				'next_text' => '<span class="meta-nav" aria-hidden="true">' . __( 'Next', 'ucr3' ) . '</span> ' .
					'<span class="screen-reader-text">' . __( 'Next post:', 'ucr3' ) . '</span> ' .
					'<span class="post-title">%title</span>',
				'prev_text' => '<span class="meta-nav" aria-hidden="true">' . __( 'Previous', 'ucr3' ) . '</span> ' .
					'<span class="screen-reader-text">' . __( 'Previous post:', 'ucr3' ) . '</span> ' .
					'<span class="post-title">%title</span>',
			) );

		// End the loop.
		endwhile;
		?>

		</div><!-- .columna-principal -->
	</div><!-- .content-area -->

<?php get_footer(); ?>
