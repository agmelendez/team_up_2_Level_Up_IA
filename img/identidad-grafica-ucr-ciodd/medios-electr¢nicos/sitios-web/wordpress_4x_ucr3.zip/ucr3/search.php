<?php

get_header(); ?>

	<section id="primary" class="content-area">
		<div class="columna-principal" id="columna-principal">

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<h1 class="page-title"><?php printf( __( 'Resultados de búsqueda para: %s', 'ucr3' ), get_search_query() ); ?></h1>
			</header><!-- .page-header -->

			<?php
			// Start the loop.
			while ( have_posts() ) : the_post(); ?>

				<?php
				/*
				 * Run the loop for the search to output the results.
				 * If you want to overload this in a child theme then include a file
				 * called content-search.php and that will be used instead.
				 */
				get_template_part( 'content', 'search' );

			// End the loop.
			endwhile;

			// Previous/next page navigation.
			the_posts_pagination( array(
				'prev_text'          => __( 'Página anterior', 'ucr3' ),
				'next_text'          => __( 'Página siguiente', 'ucr3' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Página', 'ucr3' ) . ' </span>',
			) );

		// If no content, include the "No posts found" template.
		else :
			get_template_part( 'content', 'none' );

		endif;
		?>

		</div><!-- .columna-principal -->
	</section><!-- .content-area -->

<?php get_footer(); ?>
