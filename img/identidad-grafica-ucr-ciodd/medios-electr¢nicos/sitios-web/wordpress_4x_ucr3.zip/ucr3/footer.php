<?php
?>


		<div id="pie-pagina" class="site-footer" role="contentinfo">
			<div class="contenido-interno" >
			<?php  if($footer != "") : ?>
			<div class="izquierda">
				<?php echo $pie_derecha; ?>
			</div>	
			<?php endif; ?>
			<?php if($pie_derecha != "") : ?>
			<div class="derecha">
				<?php echo $pie_derecha; ?>
			</div>
			<?php endif; ?>
			</div>
		</div>

</div><!-- marco-principal -->

<?php wp_footer(); ?>

</body>
</html>
