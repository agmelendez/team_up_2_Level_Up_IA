<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width">
<?php 

//error_reporting(E_ALL);
//ini_set('display_errors', TRUE);


	// Inicializando algunas variables:
	if(get_theme_mod('header_textcolor') != "blank")
		$texto_titulo = "si";
	else
		$texto_titulo = "no";
	$firma_grande = get_theme_mod('firma_grande');
	if($firma_grande != "si")
	{
		$class_desplazado = " class=\"desplazado\"";
		$class_desplazado2 = "desplazado";
	}
	else
	{
		$class_desplazado = "";
		$class_desplazado2 = "";
	}
	$AZUL = false;
	$BLANCO = false;
	$COLOR = get_theme_mod('color_scheme');
	switch($COLOR)
	{
		case "azul": $AZUL = true; break;
		case "blanco": $BLANCO = true; break;
	}
	$UBICACION_WEB = home_url( '/' );
	$PLANTILLA = "wp-content/themes/ucr3";//base_path().path_to_theme();
	$COMPRIMIR = "";
	$XX_LARGE = 2586;
	$X_LARGE = 2585;
	$LARGE = 1348;
	$MEDIUM = 1145;
	$TABLETA = 1024;
	$HD_CEL = 640;
	$CEL = 392;
	
	class Browser 
	{ 
		public static function detect() { 
			$userAgent = strtolower($_SERVER['HTTP_USER_AGENT']); 

			// Identify the browser. Check Opera and Safari first in case of spoof. Let Google Chrome be identified as Safari. 
			if (preg_match('/opera/', $userAgent)) { 
				$name = 'opera'; 
			} 
			elseif (preg_match('/webkit/', $userAgent)) { 
				$name = 'safari'; 
			} 
			elseif (preg_match('/msie/', $userAgent)) { 
				$name = 'msie'; 
			} 
			elseif (preg_match('/mozilla/', $userAgent) && !preg_match('/compatible/', $userAgent)) { 
				$name = 'mozilla'; 
			} 
			else { 
				$name = 'unrecognized'; 
			} 

			// What version? 
			if($name == 'mozilla')
			{
				if(preg_match('/.+firefox\/([\d.]+)/', $userAgent, $matches))
					$version = $matches[1];
				elseif(preg_match('/.+(?:rv|it|ra|ie)[\/: ]([\d.]+)/', $userAgent, $matches)) 
					$version = $matches[1]; 
				else
					$version = 'unknown'; 
			}
			elseif($name == 'opera')
			{
				if(preg_match('/.+version\/([\d.]+)/', $userAgent, $matches))
					$version = $matches[1];
				elseif(preg_match('/.+(?:rv|it|ra|ie)[\/: ]([\d.]+)/', $userAgent, $matches)) 
					$version = $matches[1]; 
				else
					$version = 'unknown'; 
			}			
			elseif(preg_match('/.+(?:rv|it|ra|ie)[\/: ]([\d.]+)/', $userAgent, $matches)) 
				$version = $matches[1]; 
			else 
				$version = 'unknown'; 

			// Running on what platform? 
			if (preg_match('/linux/', $userAgent)) { 
				$platform = 'linux'; 
			} 
			elseif (preg_match('/macintosh|mac os x/', $userAgent)) { 
				$platform = 'mac'; 
			} 
			elseif (preg_match('/windows|win32/', $userAgent)) { 
				$platform = 'windows'; 
			} 
			else { 
				$platform = 'unrecognized'; 
			} 

			return array( 
				'name'      => $name, 
				'version'   => $version, 
				'platform'  => $platform, 
				'userAgent' => $userAgent 
			); 
		} 
	}	
	
	
	$browser = Browser::detect();
	if($browser['name'] == "msie" && floatval($browser['version']) >= 8 && floatval($browser['version']) < 9)
		$IE8 = true;
	else
		$IE8 = false;

?>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<link rel="image_src" href="<?php echo $UBICACION_WEB.$PLANTILLA; ?>/imagenes/firma-ucr-ico.png" />
<link rel="icon" href="<?php echo $UBICACION_WEB.$PLANTILLA; ?>/imagenes/ucr-favicon.png" type="image/png" />
<link rel="shortcut icon" type="image/x-icon" href="<?php echo $UBICACION_WEB.$PLANTILLA; ?>/imagenes/ucr-favicon.ico" />
<?php if($IE8) : ?>
<script language="javascript" type="text/javascript">
<!--
	var resolucion = '';	
	if (document.documentElement.offsetWidth <= <?php echo $MEDIUM; ?>)
		resolucion = 'medium';		
	else if (document.documentElement.offsetWidth <= <?php echo $LARGE; ?>)
		resolucion = 'large';
	else if (document.documentElement.offsetWidth <= <?php echo $X_LARGE; ?>)
		resolucion = 'x-large';
	else
		resolucion = 'xx-large';
-->
</script>
<?php endif; ?>
<?php
	echo "<link rel=\"stylesheet\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/comun".$COMPRIMIR.".css\" />";
	if($AZUL)
		echo "<link rel=\"stylesheet\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/azul".$COMPRIMIR.".css\" />";
	if($BLANCO)
		echo "<link rel=\"stylesheet\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/blanco".$COMPRIMIR.".css\" />";
	if($IE8) /* IE 8 no soporta mediaquieries */
	{		
		echo "
	<script language=\"javascript\" type=\"text/javascript\">	
	document.write ('<link rel=\"stylesheet\" type=\"text/css\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/comun-' + resolucion + '".$COMPRIMIR.".css\" />');
		</script>				
	<link rel=\"stylesheet\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/ie8".$COMPRIMIR.".css\" />
		";
	}   /* FIN IE 8 */
	else
	{
		echo "
	<link rel=\"stylesheet\" media=\"screen and (min-width: ".($X_LARGE + 1)."px)\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/comun-xx-large".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".$X_LARGE."px) and (min-width: ".($LARGE + 1)."px)\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/comun-x-large".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".$LARGE."px) and (min-width: ".($MEDIUM + 1)."px)\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/comun-large".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".$MEDIUM."px)\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/comun-medium".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".$TABLETA."px)\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/tableta".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (width: ".$HD_CEL."px)\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/cel-large".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".($HD_CEL - 1)."px)\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/cel-medium".$COMPRIMIR.".css\" />
	<link rel=\"stylesheet\" media=\"screen and (max-width: ".$CEL."px)\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/cel-small".$COMPRIMIR.".css\" />
		";
	}

	echo "<link rel=\"stylesheet\" media=\"print\" href=\"".$UBICACION_WEB.$PLANTILLA."/css/comun-x-large".$COMPRIMIR.".css\" />";
?>
	<?php wp_head(); ?>
</head>

<body id="ucr" <?php body_class($class_desplazado2); ?>>
<a name="up" id="up"></a>
<!-- <div id="page" class="hfeed site"> -->
<div id="marco-principal"<?php echo $class_desplazado; ?>>  
	<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'ucr3' ); ?></a>

	<div id="encabezado"<?php echo $class_desplazado; ?>>
		<div class="contenido-interno">
			<?php echo $header_left; ?>
			<?php echo $arriba_izquierda; ?>
			<div id="firma" class="izquierda"><a href="http://www.ucr.ac.cr/" id="firma-ucr" title="Universidad de Costa Rica - Página principal"><span>Universidad de Costa Rica</span></a></div>
			<?php if($logo != "") : ?>
			<div class="logo">
				<?php echo "<img src=\"".$logo."\" style=\"max-height:80px\"/>"; ?>
			</div>	
			<?php elseif($texto_titulo == "si") : ?>
			<div class="logo"><?php echo bloginfo( 'name' ); ?></div>
			<?php endif; ?> <!-- logo -->
			<?php if($header_center != "" || $arriba_centro != "") : ?>				
			<div class="centro">				
				<?php echo $header_center; ?>
				<?php echo $arriba_centro; ?>
			</div>
			<?php endif; ?>				
			<div class="derecha" id="menus-iconos-funciones">
				<?php echo $header_right; ?>
				<?php echo $arriba_derecha; ?>			
			</div> <!-- arriba-derecha -->
		</div> <!-- contenido-interno -->
	</div>	<!-- encabezado -->	

	
	
		<div id="centro-arriba"<?php echo $class_desplazado.$class_menu; ?>>			
			<div id="menus-principales">
				<div class="contenido-interno">
				<?php echo $centro_arriba ?>
				</div>
			</div>
		</div>
		<div id="inicio-contenidos"></div><!-- CENTRO_ARRIBA -->
		
		<?php //get_sidebar(); ?>

