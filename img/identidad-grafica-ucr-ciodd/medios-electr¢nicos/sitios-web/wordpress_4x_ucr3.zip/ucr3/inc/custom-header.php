<?php

function ucr3_custom_header_setup() {
	$color_scheme        = ucr3_get_color_scheme();
	$default_text_color  = trim( $color_scheme[4], '#' );


	add_theme_support( 'custom-header', apply_filters( 'ucr3_custom_header_args', array(
		'default-text-color'     => $default_text_color,
		'width'                  => 954,
		'height'                 => 1300,
		'wp-head-callback'       => 'ucr3_header_style',
	) ) );
}
add_action( 'after_setup_theme', 'ucr3_custom_header_setup' );

