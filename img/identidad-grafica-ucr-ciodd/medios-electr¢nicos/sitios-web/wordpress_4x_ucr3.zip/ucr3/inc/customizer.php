<?php

//error_reporting(E_ALL);
//ini_set('display_errors', TRUE);

function ucr3_customize_register( $wp_customize ) {
	$color_scheme = ucr3_get_color_scheme();

	$wp_customize->get_setting( 'blogname' )->transport        = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';

	// Add color scheme setting and control.
	$wp_customize->add_setting( 'color_scheme', array(
		'default'           => 'celeste',
		'transport'         => 'postMessage',
	) );
	
	$wp_customize->add_control( 'color_scheme', array(
		'label'    => __( 'Color', 'ucr3' ),
		'description' => __( 'Color del tema de la plantilla.', 'ucr3' ),
		'section'  => 'colors',
		'type'     => 'select',
		'choices'  => array(             // <-- change this array
			'celeste' => 'Celeste',
			'azul' => 'Azul',
			'blanco' => 'Blanco',
		),
		'priority' => 1,
	) );

	// Remove the core header textcolor control, as it shares the sidebar text color.
	$wp_customize->remove_control( 'header_textcolor' );
	$wp_customize->remove_control( 'background_color' );
	
	
	$wp_customize->add_setting( 'firma_grande', array(
		'default'           => 'no',
		'transport'         => 'postMessage',
	) );
	
	$wp_customize->add_control( 'firma_grande', array(
		'label'    => __( 'Firma Grande', 'ucr3' ),
		'description' => __( 'Desplegar el encabezado con una firma UCR grande.', 'ucr3' ),
		'section'  => 'header_image',
		'type'     => 'select',
		'choices'  => array(             // <-- change this array
			'no' => 'No',
			'si' => 'Si',
		),
		'priority' => 1,
	) );

}
add_action( 'customize_register', 'ucr3_customize_register', 11 );

function ucr3_get_color_schemes() {
	return apply_filters( 'ucr3_color_schemes', array(
		'default' => array(
			'label'  => __( 'Default', 'ucr3' ),
			'colors' => array(
				'#f1f1f1',
				'#ffffff',
				'#ffffff',
				'#333333',
				'#333333',
				'#f7f7f7',
			),
		),
		'dark'    => array(
			'label'  => __( 'Dark', 'ucr3' ),
			'colors' => array(
				'#111111',
				'#202020',
				'#202020',
				'#bebebe',
				'#bebebe',
				'#1b1b1b',
			),
		),
		'yellow'  => array(
			'label'  => __( 'Yellow', 'ucr3' ),
			'colors' => array(
				'#f4ca16',
				'#ffdf00',
				'#ffffff',
				'#111111',
				'#111111',
				'#f1f1f1',
			),
		),
		'pink'    => array(
			'label'  => __( 'Pink', 'ucr3' ),
			'colors' => array(
				'#ffe5d1',
				'#e53b51',
				'#ffffff',
				'#352712',
				'#ffffff',
				'#f1f1f1',
			),
		),
		'purple'  => array(
			'label'  => __( 'Purple', 'ucr3' ),
			'colors' => array(
				'#674970',
				'#2e2256',
				'#ffffff',
				'#2e2256',
				'#ffffff',
				'#f1f1f1',
			),
		),
		'blue'   => array(
			'label'  => __( 'Blue', 'ucr3' ),
			'colors' => array(
				'#e9f2f9',
				'#55c3dc',
				'#ffffff',
				'#22313f',
				'#ffffff',
				'#f1f1f1',
			),
		),
	) );
}

if ( ! function_exists( 'ucr3_get_color_scheme' ) ) :

function ucr3_get_color_scheme() {
	$color_scheme_option = get_theme_mod( 'color_scheme', 'default' );
	$color_schemes       = ucr3_get_color_schemes();

	if ( array_key_exists( $color_scheme_option, $color_schemes ) ) {
		return $color_schemes[ $color_scheme_option ]['colors'];
	}

	return $color_schemes['default']['colors'];
}
endif; // ucr3_get_color_scheme
