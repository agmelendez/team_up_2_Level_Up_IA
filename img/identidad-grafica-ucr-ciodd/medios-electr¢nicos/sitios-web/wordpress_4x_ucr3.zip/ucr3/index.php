<?php

get_header(); ?>

	<div id="contenidos" class="contenido-interno content-area">
	<!-- <div id="primary" class="content-area"> -->
		<div class="columna-principal" id="columna-principal">

		<?php if ( have_posts() ) : ?>

			<?php if ( is_home() && ! is_front_page() ) : ?>
				<header>
					<h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
				</header>
			<?php endif; ?>

			<?php
			// Start the loop.
			while ( have_posts() ) : the_post();

				/*
				 * Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
				get_template_part( 'content', get_post_format() );

			// End the loop.
			endwhile;

			// Previous/next page navigation.
			the_posts_pagination( array(
				'prev_text'          => __( 'Página Anterior', 'ucr3' ),
				'next_text'          => __( 'Página Siguiente', 'ucr3' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Página', 'ucr3' ) . ' </span>',
			) );

		// If no content, include the "No posts found" template.
		else :
			get_template_part( 'content', 'none' );

		endif;
		?>

		</div><!-- .columna-principal -->
	</div><!-- .content-area -->

<?php get_footer(); ?>
