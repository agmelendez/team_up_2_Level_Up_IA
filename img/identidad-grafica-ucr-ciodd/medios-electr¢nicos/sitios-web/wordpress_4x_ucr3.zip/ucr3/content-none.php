<?php

 */
?>

<section class="no-results not-found">
	<header class="page-header">
		<h1 class="page-title"><?php _e( 'No hay resultados', 'ucr3' ); ?></h1>
	</header><!-- .page-header -->

	<div class="page-content">

		<?php if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>

			<p><?php printf( __( 'Listo para publicar su primer posteo? <a href="%1$s">Comience aquí</a>.', 'ucr3' ), esc_url( admin_url( 'post-new.php' ) ) ); ?></p>

		<?php elseif ( is_search() ) : ?>

			<p><?php _e( 'Ningún contenido tiene sus palabras de búsqueda. Por favor intente de nuevo con otras palabras clave.', 'ucr3' ); ?></p>
			<?php get_search_form(); ?>

		<?php else : ?>

			<p><?php _e( 'Parece que no puede encontrar lo que busca. Tal vez haciendo una búsqueda ayude.', 'ucr3' ); ?></p>
			<?php get_search_form(); ?>

		<?php endif; ?>

	</div><!-- .page-content -->
</section><!-- .no-results -->
